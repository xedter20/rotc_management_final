npx prisma migrate dev
npx prisma db push
